#pragma once
#include <iostream>
#include <stdlib.h> 
#define Width 960.0f
#define Hight 540.0f
#define NearPlane 0.1f
#define FarPlane 100.0f
#define FOV 90
#define AREA static_cast<int>(Width*Hight)
#define Aspect Hight/Width
#define C2C(c) (((c&65280u)<<0x8u)|((c&4278190080u)>>0x18u)|((c&255u)<<0x18u)|((c&16711680u)>>0x08u))
#define Clamp(val,min,max) (val) = ((val)<(min))?(min):(((val) > (max))?(max):(val))
#define Min(a,b) std::min(a,b)
#define Max(a,b) std::max(a,b)
#define RotSpeed 0.005f
#define PIE 3.141592653589793238462643383279
#define DegToRan(Deg) Deg*(0.0174532925)//PIE / 180.0f 
#define Cot(x) std::cos(x)/std::sin(x)
#define Black 0xFF000000
#define White 0xFFFFFFFF
#define _Color 0xFF202020
unsigned Pixel[AREA];
float Zbuffer[AREA];
struct VERTEX
{
	float xyzw[4] = {0,0,0,1};
	
	float UV[2];
	float Norm[3];
	unsigned color;
};

struct Matrix3X3
{
	union {
		float m[9];
		float mat[3][3];
	};
};

struct Matrix4X4
{
	union {
		float m[16];
		float mat[4][4];
	};
};