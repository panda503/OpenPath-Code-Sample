#pragma once
#include "Define.h"
float FMAP(float val, float IMin, float IMax, float OMin, float OMax) {

	val = Clamp(val, IMin, IMax);
	return ((val - IMin) * (OMax - OMin) / (IMax - IMin) + OMin);
}
void NDC_To_Pos(VERTEX& pix) {
	pix.xyzw[0] = (pix.xyzw[0] + 1) * (Width * 0.5f);
	pix.xyzw[1] = (1-pix.xyzw[1]) * (Hight*0.5f);
}
int D2TD3(int X, int Y) {
	return (Y * Width) + X;
}
float Lerp(float a, float b, float r) {
	return (b - a) * r + a;
}
float ImplicitLine(VERTEX _a, VERTEX _b, VERTEX _p) {
    return (_a.xyzw[1] - _b.xyzw[1]) * _p.xyzw[0] + (_b.xyzw[0] - _a.xyzw[0]) * _p.xyzw[1] + _a.xyzw[0] * _b.xyzw[1] - _b.xyzw[0] * _a.xyzw[1];
}
unsigned int Blend(unsigned int PixA, unsigned int PixB) {
	float AA = ((PixA & 0xFF000000) >> 24);
	float AR = ((PixA & 0x00FF0000) >> 16);
	float AG = ((PixA & 0x0000FF00) >> 8);
	float AB = (PixA & 0x000000FF);
	float BA = ((PixB & 0xFF000000) >> 24);
	float BR = ((PixB & 0x00FF0000) >> 16);
	float BG = ((PixB & 0x0000FF00) >> 8);
	float BB = (PixB & 0x000000FF);
	float r = FMAP(BA, 0, 255, 0, 1);
	int X = (BA - AA) * r + AA;
	int R = (BR - AR) * r + AR;
	int G = (BG - AG) * r + AG;
	int B = (BB - AB) * r + AB;
	return (X << 24) | (R << 16) | (G << 8) | B;
}
unsigned int Blend(unsigned int PixA, unsigned int PixB,float r) {
	float AA = ((PixA & 0xFF000000) >> 24);
	float AR = ((PixA & 0x00FF0000) >> 16);
	float AG = ((PixA & 0x0000FF00) >> 8);
	float AB = (PixA & 0x000000FF);
	float BA = ((PixB & 0xFF000000) >> 24);
	float BR = ((PixB & 0x00FF0000) >> 16);
	float BG = ((PixB & 0x0000FF00) >> 8);
	float BB = (PixB & 0x000000FF);
	int X = (BA - AA) * r + AA;
	int R = (BR - AR) * r + AR;
	int G = (BG - AG) * r + AG;
	int B = (BB - AB) * r + AB;
	return (X << 24) | (R << 16) | (G << 8) | B;
}
float BarycentricInterpolation(float a, float b, float c, VERTEX bay) {
	return (a * bay.xyzw[0]) + (b * bay.xyzw[1]) + (c*bay.xyzw[2]);
}
unsigned int ColorBarycentricInterpolation(unsigned int a, unsigned int b, unsigned c, VERTEX bay) {
	float AA = ((a & 0xFF000000) >> 24);
	float AR = ((a & 0x00FF0000) >> 16);
	float AG = ((a & 0x0000FF00) >> 8);
	float AB = (a& 0x000000FF);
	float BA = ((b & 0xFF000000) >> 24);
	float BR = ((b & 0x00FF0000) >> 16);
	float BG = ((b & 0x0000FF00) >> 8);
	float BB = (b& 0x000000FF);
	float CA = ((c & 0xFF000000) >> 24);
	float CR = ((c & 0x00FF0000) >> 16);
	float CG = ((c & 0x0000FF00) >> 8);
	float CB = (c & 0x000000FF);

	int r = (BarycentricInterpolation(AR, BR, CR, bay));
	int g = (BarycentricInterpolation(AG, BG, CG, bay));
	int C_b = (BarycentricInterpolation(AB, BB, CB, bay));
	int x = (BarycentricInterpolation(AA, BA, CA, bay));
	return (x << 24)|(r << 16)|(g << 8)|C_b;
}

//Matrix3X3 XRot(float Deg) {
//	Matrix3X3 ret = {};
//	ret.mat[1][1] = cos(Deg);
//	ret.mat[2][1] = -sin(Deg);
//	ret.mat[1][2] = sin(Deg);
//	ret.mat[2][2] = cos(Deg);
//	ret.mat[0][0] = 1;
//	return ret;
//}
//Matrix3X3 YRot(float Deg) {
//	Matrix3X3 ret = {};
//	ret.mat[0][0] = cos(Deg);
//	ret.mat[2][0] = -sin(Deg);
//	ret.mat[0][2] = sin(Deg);
//	ret.mat[2][2] = cos(Deg);
//	ret.mat[1][1] = 1;
//	return ret;
//}
//Matrix3X3 ZRot(float Deg) {
//	Matrix3X3 ret = {};
//	ret.mat[0][0] = cos(Deg);
//	ret.mat[1][0] = -sin(Deg);
//	ret.mat[0][1] = sin(Deg);
//	ret.mat[1][1] = cos(Deg);
//	ret.mat[2][2] = 1;
//	return ret;
//}
void MultiplyVertexByMatrix(VERTEX& cord, Matrix3X3 World) {
	VERTEX ret = cord;
	ret.xyzw[0] = cord.xyzw[0] * World.m[0] + cord.xyzw[1] * World.m[3] + cord.xyzw[2] * World.m[6];
	ret.xyzw[1] = cord.xyzw[0] * World.m[1] + cord.xyzw[1] * World.m[4] + cord.xyzw[2] * World.m[7];
	ret.xyzw[2] = cord.xyzw[0] * World.m[2] + cord.xyzw[1] * World.m[5] + cord.xyzw[2] * World.m[8];
	cord = ret;
}
VERTEX MultiplyVertexByMatrix(VERTEX cord, Matrix3X3 World) {
	VERTEX ret = cord;
	ret.xyzw[0] = cord.xyzw[0] * World.m[0] + cord.xyzw[1] * World.m[3] + cord.xyzw[2] * World.m[6];
	ret.xyzw[1] = cord.xyzw[0] * World.m[1] + cord.xyzw[1] * World.m[4] + cord.xyzw[2] * World.m[7];
	ret.xyzw[2] = cord.xyzw[0] * World.m[2] + cord.xyzw[1] * World.m[5] + cord.xyzw[2] * World.m[8];
	return ret;
}
Matrix4X4 XRot(float Deg) {
	Matrix4X4 ret = {};
	ret.mat[1][1] = cos(Deg);
	ret.mat[1][2] = -sin(Deg);
	ret.mat[2][1] = sin(Deg);
	ret.mat[2][2] = cos(Deg);
	ret.mat[0][0] = 1;
	ret.mat[3][3] = 1;
	return ret;
}
Matrix4X4 YRot(float Deg) {
	Matrix4X4 ret = {};
	ret.mat[0][0] = cos(Deg);
	ret.mat[2][0] = -sin(Deg);
	ret.mat[0][2] = sin(Deg);
	ret.mat[2][2] = cos(Deg);
	ret.mat[1][1] = 1;
	ret.mat[3][3] = 1;
	return ret;
}
Matrix4X4 ZRot(float Deg) {
	Matrix4X4 ret = {};
	ret.mat[0][0] = cos(Deg);
	ret.mat[1][0] = -sin(Deg);
	ret.mat[0][1] = sin(Deg);
	ret.mat[1][1] = cos(Deg);
	ret.mat[2][2] = 1;
	ret.mat[3][3] = 1;
	return ret;
}
Matrix4X4 Identity() {
	Matrix4X4 ret = {};
	ret.mat[0][0] = 1;
	ret.mat[1][1] = 1;
	ret.mat[2][2] = 1;
	ret.mat[3][3] = 1;
	return ret;
}
Matrix4X4 Translation(float X,float Y,float Z) {
	Matrix4X4 ret = {};
	ret.mat[3][0] = X;
	ret.mat[3][1] = Y;
	ret.mat[3][2] = Z;

	ret.mat[0][0] = 1;
	ret.mat[1][1] = 1;
	ret.mat[2][2] = 1;
	ret.mat[3][3] = 1;
	return ret;
}
Matrix4X4 Scaling(float Scale) {
	Matrix4X4 ret = {};
	ret.mat[0][0] = Scale;
	ret.mat[1][1] = Scale;
	ret.mat[2][2] = Scale;
	ret.mat[3][3] = 1;
	return ret;
}
Matrix4X4 MatrixAdding(Matrix4X4 a, Matrix4X4 b) {
	Matrix4X4 ret = {};
	return ret;
}
Matrix4X4 MatrixMultiplication(Matrix4X4 a, Matrix4X4 b) {
	Matrix4X4 res = {};
	int i, j, k;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 4; j++) {
			res.mat[i][j] = 0;
			for (k = 0; k < 4; k++)
				res.mat[i][j] += a.mat[i][k] * b.mat[k][j];
		}
	}
	return res;
}
Matrix4X4 InVerseMatrix(Matrix4X4 m) {
	float det;
	Matrix4X4 ret;
	Matrix4X4 inv;
	inv.m[0] = m.m[5] * m.m[10] * m.m[15] - m.m[5] * m.m[11] * m.m[14] -m.m[9] * m.m[6] * m.m[15] +	m.m[9] * m.m[7] * m.m[14] + m.m[13] * m.m[6] * m.m[11] - m.m[13] * m.m[7] * m.m[10];
	inv.m[4] = -m.m[4] * m.m[10] * m.m[15] +m.m[4] * m.m[11] * m.m[14] +m.m[8] * m.m[6] * m.m[15] -m.m[8] * m.m[7] * m.m[14] -m.m[12] * m.m[6] * m.m[11] +m.m[12] * m.m[7] * m.m[10];
	inv.m[8] = m.m[4] * m.m[9] * m.m[15] - m.m[4] * m.m[11] * m.m[13] - m.m[8] * m.m[5] * m.m[15] + m.m[8] * m.m[7] * m.m[13] + m.m[12] * m.m[5] * m.m[11] - m.m[12] * m.m[7] * m.m[9];
	inv.m[12] = -m.m[4] * m.m[9] * m.m[14] + m.m[4] * m.m[10] * m.m[13] + m.m[8] * m.m[5] * m.m[14] - m.m[8] * m.m[6] * m.m[13] - m.m[12] * m.m[5] * m.m[10] + m.m[12] * m.m[6] * m.m[9];
	inv.m[1] = -m.m[1] * m.m[10] * m.m[15] + m.m[1] * m.m[11] * m.m[14] + m.m[9] * m.m[2] * m.m[15] - m.m[9] * m.m[3] * m.m[14] - m.m[13] * m.m[2] * m.m[11] + m.m[13] * m.m[3] * m.m[10];
	inv.m[5] = m.m[0] * m.m[10] * m.m[15] - m.m[0] * m.m[11] * m.m[14] - m.m[8] * m.m[2] * m.m[15] + m.m[8] * m.m[3] * m.m[14] + m.m[12] * m.m[2] * m.m[11] - m.m[12] * m.m[3] * m.m[10];
	inv.m[9] = -m.m[0] * m.m[9] * m.m[15] + m.m[0] * m.m[11] * m.m[13] + m.m[8] * m.m[1] * m.m[15] - m.m[8] * m.m[3] * m.m[13] - m.m[12] * m.m[1] * m.m[11] + m.m[12] * m.m[3] * m.m[9];
	inv.m[13] = m.m[0] * m.m[9] * m.m[14] - m.m[0] * m.m[10] * m.m[13] - m.m[8] * m.m[1] * m.m[14] + m.m[8] * m.m[2] * m.m[13] + m.m[12] * m.m[1] * m.m[10] - m.m[12] * m.m[2] * m.m[9];
	inv.m[2] = m.m[1] * m.m[6] * m.m[15] - m.m[1] * m.m[7] * m.m[14] - m.m[5] * m.m[2] * m.m[15] + m.m[5] * m.m[3] * m.m[14] + m.m[13] * m.m[2] * m.m[7] - m.m[13] * m.m[3] * m.m[6];
	inv.m[6] = -m.m[0] * m.m[6] * m.m[15] + m.m[0] * m.m[7] * m.m[14] + m.m[4] * m.m[2] * m.m[15] - m.m[4] * m.m[3] * m.m[14] - m.m[12] * m.m[2] * m.m[7] + m.m[12] * m.m[3] * m.m[6];
	inv.m[10] = m.m[0] * m.m[5] * m.m[15] - m.m[0] * m.m[7] * m.m[13] - m.m[4] * m.m[1] * m.m[15] + m.m[4] * m.m[3] * m.m[13] + m.m[12] * m.m[1] * m.m[7] - m.m[12] * m.m[3] * m.m[5];
	inv.m[14] = -m.m[0] * m.m[5] * m.m[14] + m.m[0] * m.m[6] * m.m[13] + m.m[4] * m.m[1] * m.m[14] - m.m[4] * m.m[2] * m.m[13] - m.m[12] * m.m[1] * m.m[6] + m.m[12] * m.m[2] * m.m[5];
	inv.m[3] = -m.m[1] * m.m[6] * m.m[11] + m.m[1] * m.m[7] * m.m[10] + m.m[5] * m.m[2] * m.m[11] - m.m[5] * m.m[3] * m.m[10] - m.m[9] * m.m[2] * m.m[7] + m.m[9] * m.m[3] * m.m[6];
	inv.m[7] = m.m[0] * m.m[6] * m.m[11] - m.m[0] * m.m[7] * m.m[10] - m.m[4] * m.m[2] * m.m[11] + m.m[4] * m.m[3] * m.m[10] + m.m[8] * m.m[2] * m.m[7] - m.m[8] * m.m[3] * m.m[6];
	inv.m[11] = -m.m[0] * m.m[5] * m.m[11] + m.m[0] * m.m[7] * m.m[9] + m.m[4] * m.m[1] * m.m[11] - m.m[4] * m.m[3] * m.m[9] - m.m[8] * m.m[1] * m.m[7] + m.m[8] * m.m[3] * m.m[5];
	inv.m[15] = m.m[0] * m.m[5] * m.m[10] - m.m[0] * m.m[6] * m.m[9] - m.m[4] * m.m[1] * m.m[10] + m.m[4] * m.m[2] * m.m[9] + m.m[8] * m.m[1] * m.m[6] - m.m[8] * m.m[2] * m.m[5];
	det = m.m[0] * inv.m[0] + m.m[1] * inv.m[4] + m.m[2] * inv.m[8] + m.m[3] * inv.m[12];

	if (det == 0)
		return m;

	det = 1.0 / det;

	for (int i = 0; i < 16; i++)
		ret.m[i] = inv.m[i] * det;
	return ret;
}
void MultiplyVertexByMatrix(VERTEX& cord, Matrix4X4 World) {
	VERTEX ret = cord;
	ret.xyzw[0] = cord.xyzw[0] * World.m[0] + cord.xyzw[1] * World.m[4] + cord.xyzw[2] * World.m[8] + cord.xyzw[3] * World.m[12];
	ret.xyzw[1] = cord.xyzw[0] * World.m[1] + cord.xyzw[1] * World.m[5] + cord.xyzw[2] * World.m[9] + cord.xyzw[3] * World.m[13];
	ret.xyzw[2] = cord.xyzw[0] * World.m[2] + cord.xyzw[1] * World.m[6] + cord.xyzw[2] * World.m[10] + cord.xyzw[3] * World.m[14];
	ret.xyzw[3] = cord.xyzw[0] * World.m[3] + cord.xyzw[1] * World.m[7] + cord.xyzw[2] * World.m[11] + cord.xyzw[3] * World.m[15];
	cord = ret;
}
Matrix4X4 PerProjection() {
	Matrix4X4 ret = {};
	float YScale = 1.0f/tan(.5f * static_cast<float>((DegToRan(FOV))));
	ret.mat[1][1]= YScale;
	ret.mat[0][0]= YScale * Aspect;
	ret.mat[2][2]= FarPlane/(FarPlane-NearPlane);
	ret.mat[2][3] = 1;
	ret.mat[3][2]= -(FarPlane * NearPlane)/(FarPlane - NearPlane);
	return ret;
}

void Homogenize(VERTEX& h) {
	h.xyzw[0] = h.xyzw[0] / h.xyzw[3];
	h.xyzw[1] = h.xyzw[1] / h.xyzw[3];
	h.xyzw[2] = h.xyzw[2] / h.xyzw[3];
}
Matrix4X4 MatrixInverse4x4(Matrix4X4 _input) {
	Matrix4X4 inverse = { 0 };

	Matrix3X3 transpose = { 0 };
	transpose.mat[0][0] = _input.mat[0][0];
	transpose.mat[1][1] = _input.mat[1][1];
	transpose.mat[2][2] = _input.mat[2][2];
	transpose.mat[0][1] = _input.mat[1][0];
	transpose.mat[0][2] = _input.mat[2][0];
	transpose.mat[1][0] = _input.mat[0][1];
	transpose.mat[1][2] = _input.mat[2][1];
	transpose.mat[2][0] = _input.mat[0][2];
	transpose.mat[2][1] = _input.mat[1][2];

	for (int i = 0; i < 3; ++i)
		for (int j = 0; j < 3; ++j)
			inverse.mat[i][j] = transpose.mat[i][j];

	VERTEX result = MultiplyVertexByMatrix({ _input.mat[3][0], _input.mat[3][1], _input.mat[3][2], _input.mat[3][3] }, transpose);
	inverse.mat[3][0] = -result.xyzw[0];
	inverse.mat[3][1] = -result.xyzw[1];
	inverse.mat[3][2] = -result.xyzw[2];
	inverse.mat[3][3] = result.xyzw[3];

	return inverse;
}
void VertexLerp(VERTEX& ret, VERTEX a, VERTEX b, float R) {//B should be a high number;
	
	ret.xyzw[0] = (b.xyzw[0] -a.xyzw[0]) * R + a.xyzw[0];
	ret.xyzw[1] = (b.xyzw[1] - a.xyzw[1]) * R + a.xyzw[1];
	ret.xyzw[2] = (b.xyzw[2] - a.xyzw[2]) * R + a.xyzw[2];
	ret.xyzw[3] = (b.xyzw[3] - a.xyzw[3]) * R + a.xyzw[3];

	ret.UV[0] = (b.UV[0] - a.UV[0]) * R + a.UV[0];
	ret.UV[1] = (b.UV[1] - a.UV[1]) * R + a.UV[1];

	//ret.color = Blend(a.color,b.color);
}
float Dot(VERTEX A, VERTEX B) {
	return A.xyzw[0] * B.xyzw[0] + A.xyzw[1] + B.xyzw[1] + A.xyzw[2] * B.xyzw[2];
}
VERTEX Cross(VERTEX A, VERTEX B) {
	return { A.xyzw[1] * B.xyzw[2] - B.xyzw[1] * A.xyzw[2],
			 A.xyzw[2] * B.xyzw[0] - B.xyzw[2] * A.xyzw[0],
			 A.xyzw[0] * B.xyzw[1] - B.xyzw[0] * A.xyzw[1] };
}
float VecLength(VERTEX A) {
	return sqrt(A.xyzw[0] * A.xyzw[0] + A.xyzw[1] * A.xyzw[1] + A.xyzw[2] * A.xyzw[2]);
}
VERTEX VecNorm(VERTEX A) {
	float d = VecLength(A);
	if (d != 0)
		return { A.xyzw[0] / d, A.xyzw[1] / d, A.xyzw[2] / d };
	return { 0, 0, 0, 1 };
}
float BarycentricPoint(VERTEX v, float a, float b, float c) {
	return { v.xyzw[0] * a + v.xyzw[1] * b + v.xyzw[2] * c };
}
unsigned ColorModulate(unsigned A, unsigned B) {
	float A1 = ((A & 0xFF000000) >> 24) / 255.0f;
	float A2 = ((A & 0x00FF0000) >> 16) / 255.0f;
	float A3 = ((A & 0x0000FF00) >> 8) / 255.0f;
	float A4 = ((A & 0x000000FF)) / 255.0f;
	float B1 = ((B & 0xFF000000) >> 24) / 255.0f;
	float B2 = ((B & 0x00FF0000) >> 16) / 255.0f;
	float B3 = ((B & 0x0000FF00) >> 8) / 255.0f;
	float B4 = ((B & 0x000000FF)) / 255.0f;
	int F1 = (A1 * B1) * 255;
	int F2 = (A2 * B2) * 255;
	int F3 = (A3 * B3) * 255;
	int F4 = (A4 * B4) * 255;
	F1 = F1 > 255 ? 255 : F1;
	F2 = F2 > 255 ? 255 : F2;
	F3 = F3 > 255 ? 255 : F3;
	F4 = F4 > 255 ? 255 : F4;
	return (F1 << 24) | (F2 << 16) | (F3 << 8) | F4;
}
unsigned ColorAddition(unsigned A, unsigned B) {
	float A1 = ((A & 0xFF000000) >> 24) / 255.0f;
	float A2 = ((A & 0x00FF0000) >> 16) / 255.0f;
	float A3 = ((A & 0x0000FF00) >> 8) / 255.0f;
	float A4 = ((A & 0x000000FF)) / 255.0f;
	float B1 = ((B & 0xFF000000) >> 24) / 255.0f;
	float B2 = ((B & 0x00FF0000) >> 16) / 255.0f;
	float B3 = ((B & 0x0000FF00) >> 8) / 255.0f;
	float B4 = ((B & 0x000000FF)) / 255.0f;
	int F1 = (A1 + B1) * 255;
	int F2 = (A2 + B2) * 255;
	int F3 = (A3 + B3) * 255;
	int F4 = (A4 + B4) * 255;
	F1 = F1 > 255 ? 255 : F1;
	F2 = F2 > 255 ? 255 : F2;
	F3 = F3 > 255 ? 255 : F3;
	F4 = F4 > 255 ? 255 : F4;
	return (F1 << 24) | (F2 << 16) | (F3 << 8) | F4;
}

//void Inverse(HCMATRIX _input, HCMATRIX& _output) {
//
//	float det;
//	float a0 = _input.m[0] * _input.m[5] - _input.m[1] * _input.m[4];
//	float a1 = _input.m[0] * _input.m[6] - _input.m[2] * _input.m[4];
//	float a2 = _input.m[0] * _input.m[7] - _input.m[3] * _input.m[4];
//	float a3 = _input.m[1] * _input.m[6] - _input.m[2] * _input.m[5];
//	float a4 = _input.m[1] * _input.m[7] - _input.m[3] * _input.m[5];
//	float a5 = _input.m[2] * _input.m[7] - _input.m[3] * _input.m[6];
//	float b0 = _input.m[8] * _input.m[13] - _input.m[9] * _input.m[12];
//	float b1 = _input.m[8] * _input.m[14] - _input.m[10] * _input.m[12];
//	float b2 = _input.m[8] * _input.m[15] - _input.m[11] * _input.m[12];
//	float b3 = _input.m[9] * _input.m[14] - _input.m[10] * _input.m[13];
//	float b4 = _input.m[9] * _input.m[15] - _input.m[11] * _input.m[13];
//	float b5 = _input.m[10] * _input.m[15] - _input.m[11] * _input.m[14];
//	det = a0 * b5 - a1 * b4 + a2 * b3 + a3 * b2 - a4 * b1 + a5 * b0;
//
//	if (det == 0) {
//		_output = _input;
//		return HCRETURN::DEFAULT_ZERO;
//	}
//	_output.row1 = { _input.m[5] * b5 - _input.m[6] * b4 + _input.m[7] * b3,
//					 -_input.m[1] * b5 + _input.m[2] * b4 - _input.m[3] * b3,
//					 _input.m[13] * a5 - _input.m[14] * a4 + _input.m[15] * a3,
//					 -_input.m[9] * a5 + _input.m[10] * a4 - _input.m[11] * a3 };
//
//	_output.row2 = { -_input.m[4] * b5 + _input.m[6] * b2 - _input.m[7] * b1,
//					 _input.m[0] * b5 - _input.m[2] * b2 + _input.m[3] * b1,
//					 -_input.m[12] * a5 + _input.m[14] * a2 - _input.m[15] * a1,
//					 _input.m[8] * a5 - _input.m[10] * a2 + _input.m[11] * a1 };
//
//	_output.row3 = { _input.m[4] * b4 - _input.m[5] * b2 + _input.m[7] * b0,
//					 -_input.m[0] * b4 + _input.m[1] * b2 - _input.m[3] * b0,
//					 _input.m[12] * a4 - _input.m[13] * a2 + _input.m[15] * a0,
//					 -_input.m[8] * a4 + _input.m[9] * a2 - _input.m[11] * a0 };
//
//	_output.row4 = { -_input.m[4] * b3 + _input.m[5] * b1 - _input.m[6] * b0,
//					 _input.m[0] * b3 - _input.m[1] * b1 + _input.m[2] * b0,
//					 -_input.m[12] * a3 + _input.m[13] * a1 - _input.m[14] * a0,
//					 _input.m[8] * a3 - _input.m[9] * a1 + _input.m[10] * a0 };
//
//	ScalarMult(_output, 1.0f / det, _output);
//
//	return HCRETURN::SUCCESS;
//}
//Matrix4X4 PerspectiveProjection(float _fov, float _aspectRatio, float _zfar, float _znear) {
//	float yscale = 1.0f / tan(.5f * (_fov * static_cast<float>(PIE / 180)));
//	float xscale = yscale * _aspectRatio;
//
//	return { xscale, 0, 0, 0, 0, yscale, 0, 0, 0, 0, _zfar / (_zfar - _znear), 1, 0, 0, -(_zfar * _znear) / (_zfar - _znear), 0 };
//}