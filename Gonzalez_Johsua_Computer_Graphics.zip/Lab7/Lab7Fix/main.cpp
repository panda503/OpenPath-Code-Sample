#include <iostream>
#include "RasterSurface.h"
#include "Raster.h"
#include "StoneHenge.h"
#include  "StoneHenge_Texture.h"
#include "Math.h"
#include "Shader.h"
#include "XTime.h"

int main()
{
    XTime timer;
    timer.Restart();
    float pass = 0;
    VERTEX* Stars = new VERTEX[3000];
    SV_Distance = 1;
    float distanceSlope = 0.1f;
    srand(time(NULL));
    for (int i = 0; i < 3000; i++) {
        Stars[i].xyzw[0] = ((rand() / static_cast<float>(RAND_MAX)) * 2 - 1) * 50;
        Stars[i].xyzw[1] = ((rand() / static_cast<float>(RAND_MAX)) * 2 - 1) * 50;
        Stars[i].xyzw[2] = ((rand() / static_cast<float>(RAND_MAX)) * 2 - 1) * 50;
        Stars[i].xyzw[3] = 1;
    }
    VERTEX* StoneHendge = new VERTEX[1457];
    for (int i = 0; i < 1457; i++) {
        StoneHendge[i] = { {StoneHenge_data[i].pos[0] * 0.1f, StoneHenge_data[i].pos[1] * 0.1f, StoneHenge_data[i].pos[2] * 0.1f, 1},
                        StoneHenge_data[i].uvw[0], StoneHenge_data[i].uvw[1],
                        {StoneHenge_data[i].nrm[0], StoneHenge_data[i].nrm[1], StoneHenge_data[i].nrm[2]} };
    }
    Camra = MatrixInverse4x4(MatrixMultiplication(Translation(0, 0, -3), XRot(-18 * (PIE / 180))));
    Projection = PerProjection();
    SV_WorldMatrix = Identity();
    RS_Initialize(Width, Hight);
    do {
        timer.Signal();
        pass -= timer.Delta();
        if (pass <= 0) {
            pass = RotSpeed;
            if (GetAsyncKeyState(0x57)) { // W
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), Translation(0, 0, timer.Delta())));
            }
            if (GetAsyncKeyState(0x44)) { // D
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), Translation(timer.Delta(), 0, 0)));
            }
            if (GetAsyncKeyState(0x53)) { //S
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), Translation(0, 0, -timer.Delta())));
            }
            if (GetAsyncKeyState(0x41)) { //A
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), Translation(-timer.Delta(), 0, 0)));
            }
            if (GetAsyncKeyState(0x20)) { //Space
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), Translation(0, timer.Delta(), 0)));
            }
            if (GetAsyncKeyState(0x58)) { //X
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), Translation(0, -timer.Delta(), 0)));
            }
            if (GetAsyncKeyState(0x25)) { //Left Arrow
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), YRot(-timer.Delta())));
            }
            if (GetAsyncKeyState(0x26)) { //Up Arrow
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), XRot(-timer.Delta())));
            }
            if (GetAsyncKeyState(0x27)) { //Right Arrow
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), YRot(timer.Delta())));
            }
            if (GetAsyncKeyState(0x28)) { //Down Arrow
                Camra = MatrixInverse4x4(MatrixMultiplication(MatrixInverse4x4(Camra), XRot(timer.Delta())));
            }

            clear(0x00001A34);
            if (SV_Distance > 1.6f ) {
                distanceSlope = -0.1f;
            }
            else if (SV_Distance < 1) {
                distanceSlope = 0.1f;
            }
            if (timer.TotalTime() > 0.05f) {
                SV_Distance += distanceSlope;
                timer.Restart();
            }
            VertexShader = VS_CameraLight;
            PixelShader = PS_White;
            for (int i = 0; i < 3000; i++) {
                DrawStar(Stars[i]);
            }
            PixelShader = PS_Texter;
            for (int i = 0; i < 2532; i += 3) {
                DrawTri(StoneHendge[StoneHenge_indicies[i]], StoneHendge[StoneHenge_indicies[i + 1]], StoneHendge[StoneHenge_indicies[i + 2]]);
            }
        }
    } while (RS_Update(Pixel, Width * Hight));
    delete[] StoneHendge;
    delete[] Stars;
    RS_Shutdown();
}