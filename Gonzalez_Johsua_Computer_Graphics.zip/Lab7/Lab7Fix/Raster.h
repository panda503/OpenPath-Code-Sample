#pragma once
#include "Math.h"
#include "Define.h"
#include "Shader.h"
#include <stdlib.h> 
#include <iostream>
void clear(unsigned int Color) {
	for (size_t y = 0; y < AREA; y++)
	{
		Pixel[y] = Color;
		Zbuffer[y] = 1.0f;
	}
}
int CLANP(VERTEX& A, VERTEX& B) {
	if (A.xyzw[2] < NearPlane && B.xyzw[2] < NearPlane) return -1;
	if (A.xyzw[2] > NearPlane && B.xyzw[2] > NearPlane) return 1;
	if (A.xyzw[2] < NearPlane) {
		float r = (NearPlane - A.xyzw[2]) / (B.xyzw[2] - A.xyzw[2]);
		A.xyzw[0] = Lerp(A.xyzw[0], B.xyzw[0], r);
		A.xyzw[1] = Lerp(A.xyzw[1], B.xyzw[1], r);
		A.xyzw[2] = Lerp(A.xyzw[2], B.xyzw[2], r);
		A.xyzw[3] = Lerp(A.xyzw[3], B.xyzw[3], r);
		A.UV[0] = Lerp(A.UV[0], B.UV[0], r);
		A.UV[1] = Lerp(A.UV[1], B.UV[1], r);
		return 0;
	}
	else {
		float r = (NearPlane - B.xyzw[2]) / (A.xyzw[2] - B.xyzw[2]);
		B.xyzw[0] = Lerp(B.xyzw[0], A.xyzw[0], r);
		B.xyzw[1] = Lerp(B.xyzw[1], A.xyzw[1], r);
		B.xyzw[2] = Lerp(B.xyzw[2], A.xyzw[2], r);
		B.xyzw[3] = Lerp(B.xyzw[3], A.xyzw[3], r);
		B.UV[0] = Lerp(B.UV[0], A.UV[0], r);
		B.UV[1] = Lerp(B.UV[1], A.UV[1], r);
		return 0;
	}

}
int CTANP(VERTEX& A, VERTEX& B, VERTEX& C, VERTEX& D) {
	if (A.xyzw[2] < NearPlane && C.xyzw[2] < NearPlane && B.xyzw[2] < NearPlane) return -1;
	if (A.xyzw[2] > NearPlane && C.xyzw[2] > NearPlane && B.xyzw[2] > NearPlane) return 0;
	VERTEX copy_A = A;
	VERTEX copy_B = B;
	VERTEX copy_C = C;

	VERTEX lineAB[2] = { copy_A, copy_B };
	VERTEX lineBC[2] = { copy_B, copy_C };
	VERTEX lineCA[2] = { copy_C, copy_A };
	int results[3] = { CLANP(lineAB[0], lineAB[1]), CLANP(lineBC[0], lineBC[1]), CLANP(lineCA[0], lineCA[1]) };
	if (results[0] == -1) {
		A = lineCA[1];
		B = lineBC[0];
		C = C;
		return 1;
	}
	if (results[0] == 1) {
		A = A;
		B = B;
		C = lineBC[1];
		D = lineCA[0];
		return 2;
	}
	if (results[1] == -1) {
		A = A;
		B = lineAB[1];
		C = lineCA[0];
		return 1;
	}
	if (results[1] == 1) {
		A = lineAB[0];
		B = B;
		C = C;
		D = lineCA[1];
		return 2;
	}
	if (results[2] == -1) {
		A = lineAB[0];
		B = B;
		C = lineBC[1];
		return 1;
	}
	if (results[2] == 1) {
		A = A;
		B = lineAB[1];
		D = C;
		C = lineBC[0];
		return 2;
	}
}

void DrawPixel( unsigned int Color, int Pos) {
	Pixel[Pos] = Color;
}
void DrawPixel(int X, int Y, float Z, unsigned Color) {
	int pos = D2TD3(X, Y);
	if ((X <= Width && X >= 0) && (Y <= Hight && Y >= 0) && Z < Zbuffer[pos]) {
		Zbuffer[pos] = Z;
		Pixel[pos] = Color;
	}
}

void DrawPixel(VERTEX Pix) {
	VERTEX copy = Pix;
	if (VertexShader)
		VertexShader(copy);
	Homogenize(copy);
	NDC_To_Pos(copy);
	if (PixelShader)
		PixelShader(copy.color);
	int pos = D2TD3(copy.xyzw[0], copy.xyzw[1]);
	if ( ((copy.xyzw[0] <= Width) && (copy.xyzw[0] >= 0)) && ((copy.xyzw[1] <= Hight) && (copy.xyzw[1] >= 0))&&copy.xyzw[2] < Zbuffer[pos]) {
		Zbuffer[pos] = copy.xyzw[2];
		Pixel[pos] = copy.color;
	}
}//Do not use
void DrawStar(VERTEX p) {
	VERTEX copy = p;
	if (VertexShader)
		VertexShader(copy);
	Homogenize(copy);
	NDC_To_Pos(copy);
	if (PixelShader)
		PixelShader(copy.color);
	DrawPixel(copy.xyzw[0], copy.xyzw[1], copy.xyzw[2], copy.color);
}

void DrawLine(const VERTEX &_start, const VERTEX &_end) {
	VERTEX start = _start;
	VERTEX end = _end;
	
	if (VertexShader)
	{
		VertexShader(start);
		VertexShader(end);
	}
	//program the clipping here;
	if (CLANP(start,end) == -1) {
		return;
	}
	Homogenize(start);
	Homogenize(end);

	NDC_To_Pos(start);
	NDC_To_Pos(end);
	
	int Xdelta = std::abs(end.xyzw[0]-start.xyzw[0]);
	int Ydelta = std::abs(end.xyzw[1]-start.xyzw[1]);
	int total = std::max(Xdelta, Ydelta);
	//parametric line,(B-A)*R+A;
	for (int i = 0; i < total; ++i)
	{
		float R = (float)i / total;
		float screenX = (end.xyzw[0] -start.xyzw[0]) * R + start.xyzw[0];
		float screenY = (end.xyzw[1] -start.xyzw[1]) * R + start.xyzw[1];
		float screenZ = (end.xyzw[2] - start.xyzw[2]) * R + start.xyzw[2];
		unsigned C_Color = start.color;
		if (PixelShader) {
			PixelShader(C_Color);
		}
		DrawPixel(screenX + 0.5f, screenY + 0.5f, screenZ, C_Color);
	}
}
void FillTri(const VERTEX& a, const VERTEX& b, const VERTEX& c) {
	VERTEX newA = a;
	VERTEX newB = b;
	VERTEX newC = c;
	int lowestH = std::min(std::min(newA.xyzw[1], newB.xyzw[1]), newC.xyzw[1]);
	int highestH = std::max(std::max(newA.xyzw[1], newB.xyzw[1]), newC.xyzw[1]);
	int lowestW = std::min(std::min(newA.xyzw[0], newB.xyzw[0]), newC.xyzw[0]);
	int highestW = std::max(std::max(newA.xyzw[0], newB.xyzw[0]), newC.xyzw[0]);
	float zmin = std::min(std::min(newA.xyzw[2], newB.xyzw[2]), newC.xyzw[2]);
	float zmax = std::max(std::max(newA.xyzw[2], newB.xyzw[2]), newC.xyzw[2]);
	for (int y = lowestH; y <= highestH; y++) {
		for (int x = lowestW; x <= highestW; x++) {
			VERTEX point = { x, y };
			VERTEX bary = { ImplicitLine(point, newC, newB) / ImplicitLine(newA, newC, newB),
							ImplicitLine(point, newA, newC) / ImplicitLine(newB, newA, newC),
							ImplicitLine(point, newB, newA) / ImplicitLine(newC, newB, newA) };
			if (bary.xyzw[0] > 0 && bary.xyzw[0] < 1 && bary.xyzw[1] > 0 && bary.xyzw[1] < 1 && bary.xyzw[2] > 0 && bary.xyzw[2] < 1) {

				Light = ColorBarycentricInterpolation(newA.color, newB.color, newC.color, bary);
				unsigned C_Color = Light;
				float PCIA = BarycentricInterpolation((1.0f / newA.xyzw[3]), (1.0f / newB.xyzw[3]), (1.0f / newC.xyzw[3]), bary);
				SV_UV.xyzw[3] = BarycentricInterpolation(newA.xyzw[3], newB.xyzw[3], newC.xyzw[3], bary);
				SV_UV.UV[0] = BarycentricInterpolation((newA.UV[0] / newA.xyzw[3]), (newB.UV[0] / newB.xyzw[3]), (newC.UV[0] / newC.xyzw[3]), bary) / PCIA;
				SV_UV.UV[1] = BarycentricInterpolation((newA.UV[1] / newA.xyzw[3]), (newB.UV[1] / newB.xyzw[3]), (newC.UV[1] / newC.xyzw[3]), bary) / PCIA;
				if (PixelShader) {
					PixelShader(C_Color);
				}
				DrawPixel(x, y, BarycentricPoint(bary, newA.xyzw[2], newB.xyzw[2], newC.xyzw[2]), C_Color);    // interpolate "Z" values
			}
		}
	}
}
void DrawTri(const VERTEX& A, const VERTEX& B, const VERTEX& C) {
	VERTEX copyA = A;
	VERTEX copyB = B;
	VERTEX copyC = C;
	VERTEX copyD = {};
	if (VertexShader) {
		VertexShader(copyA);
		VertexShader(copyB);
		VertexShader(copyC);
	}
	int res = CTANP(copyA, copyB, copyC, copyD);
	if (res > -1) {
		if (res == 1 || res == 0) {

			Homogenize(copyA);
			Homogenize(copyB);
			Homogenize(copyC);
			NDC_To_Pos(copyA);
			NDC_To_Pos(copyB);
			NDC_To_Pos(copyC);
			FillTri(copyA, copyB, copyC);
		}
		else if (res == 2) {
			Homogenize(copyA);
			Homogenize(copyB);
			Homogenize(copyC);
			Homogenize(copyD);
			NDC_To_Pos(copyA);
			NDC_To_Pos(copyB);
			NDC_To_Pos(copyC);
			NDC_To_Pos(copyD);
			FillTri(copyA, copyB, copyC);
			FillTri(copyA, copyC, copyD);
		}
	}
}



void UVFace( VERTEX& _topright,VERTEX& _topleft, VERTEX& _bottomright , VERTEX& _bottomleft ) {
	_topright.UV[0] = 0;
	_topright.UV[1] = 0;
	_topleft.UV[0] = 1;
	_topleft.UV[1] = 0;
	_bottomright.UV[0] = 1;
	_bottomright.UV[1] = 1;
	_bottomleft.UV[0] = 0;
	_bottomleft.UV[1] = 1;
	
}
