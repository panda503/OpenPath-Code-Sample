#pragma once
#include "Define.h"
#include "Math.h"
#include "StoneHenge_Texture.h"


// The active vertex shader. Modifies an incoming vertex. Pre-Rasterization. 
void (*VertexShader)(VERTEX&) = 0;
// The active pixel shader. Modifies an outgoing pixel. Post-Rasterization.
void (*PixelShader)(unsigned int&) = 0;
// All Shader Variables (Always Pre-fixed by �SV_�)
Matrix4X4 SV_WorldMatrix;
Matrix4X4 Camra;
Matrix4X4 Projection;

VERTEX SV_PixelNorm;
VERTEX SV_UV = {};
unsigned Rave = 0xFFFF0000;
unsigned Fade = 0xFFFF0000;
unsigned DirColor = 0xFFC0C0F0;
unsigned PointLight = 0xFFFFFF00;
unsigned Light = 0;
float SV_Distance = 1;
// Various custom vertex and pixel shaders, (Pre-fixed by �VS_� & �PS_�)
// Can be swapped using above function pointers as needed for flexibility. 

void VS_Camera(VERTEX& pos) {
	MultiplyVertexByMatrix(pos,SV_WorldMatrix);
	MultiplyVertexByMatrix(pos, Camra);
	MultiplyVertexByMatrix(pos, Projection);
}

void VS_CameraLight(VERTEX& vertex) {
	MultiplyVertexByMatrix(vertex, SV_WorldMatrix);

	VERTEX normal = { vertex.Norm[0], vertex.Norm[1], vertex.Norm[2] };
	MultiplyVertexByMatrix(normal, SV_WorldMatrix);
	normal = VecNorm(normal);
	VERTEX origin = { -0.577, -0.577, 0.577 };
	origin = VecNorm(origin);
	float dot = -origin.xyzw[0] * normal.xyzw[0] + -origin.xyzw[1] * normal.xyzw[1] + -origin.xyzw[2] * normal.xyzw[2];
	Clamp(dot, 0, 1);
	vertex.color = Blend(_Color, DirColor, dot);
	VERTEX dif = { -1 - vertex.xyzw[0], 0.5 - vertex.xyzw[1], 1 - vertex.xyzw[2] };
	float firstAtt = VecLength(dif) / SV_Distance;
	Clamp(firstAtt,0,1);
	dif = VecNorm(dif);
	float lr = Dot(dif, normal);
	float attentuation = 1.0f - firstAtt;
	lr = lr * attentuation;
	Clamp(lr,0,1);
	vertex.color = ColorAddition(vertex.color, Blend(_Color, PointLight, lr));

	MultiplyVertexByMatrix(vertex, Camra);
	MultiplyVertexByMatrix(vertex, Projection);
}


// Applys the current world matrix to all
void VS_World(VERTEX& multiplyMe)
{
    MultiplyVertexByMatrix(multiplyMe, SV_WorldMatrix);
}
// Basic pixel shader returns the color white
void PS_White(unsigned int& Color)
{
    Color = 0xFFFFFFFF;
}
void PS_Black(unsigned int& Color) {
	Color = 0xFF000000;
}
void PS_Red(unsigned int& Color) {
	Color = 0xFFFF0000;
}
void PS_Green(unsigned int& Color) {
	Color = 0xFF00FF00;
}
void PS_Blue(unsigned int& Color) {
	Color = 0xFF0000FF;
}
void PS_Pink(unsigned int& Color) {
	Color = 0xFFffc0cb;
}
void PS_LightBlue(unsigned int& Color) {
	Color = 0xFFadd8e6;
}
void PS_Rave(unsigned int& Color) {
	Color = Rave;
}
void PS_Fade(unsigned int& Color) {
	Color = Fade;
}
void Update_Rave() {
	if (Rave == 0xFFFF0000) {
		Rave = 0xFF0000FF;
	}
	else if (Rave == 0xFF0000FF) {
		Rave = 0xFF00FF00;
	}
	else if (Rave == 0xFF00FF00) {
		Rave = 0xFFFF0000;
	}
}
void Update_Fade() {
	int AA = ((Fade & 0xFF000000) >> 24);
	int AR = ((Fade & 0x00FF0000) >> 16);
	int AG = ((Fade & 0x0000FF00) >> 8);
	int AB = (Fade & 0x000000FF);
	if (AG == 0 && AR > 0) {
		AR -= 10;
		AB += 10;
	}
	else if (AG == 0 && AR == 0) {
		AB = 255;
		AB -= 10;
		AG += 10;
	}
	else if (AR == 0 && AB > 0) {
		AB -= 10;
		AG += 10;
	}
	else if (AR == 0 && AB == 0) {
		AG == 255;
		AG -= 10;
		AR += 10;
	}
	else if (AB == 0 && AG > 0) {
		AG -= 10;
		AR += 10;
	}
	else if (AB == 0 && AG == 0) {
		AR = 255;
		AR -= 10;
		AB += 10;
	}
	//AA = Clamp(AA,0,255);
	AR = Clamp(AR, 0, 255);
	AG = Clamp(AG, 0, 255);
	AB = Clamp(AB, 0, 255);
	Fade = (AA << 24) | (AR << 16) | (AG << 8) | AB;
}
void PS_Texter(unsigned int& Color) {
	//level = (W-N)/(F-N) * numlevels
	int mip = ((SV_UV.xyzw[3] - NearPlane) / (FarPlane - NearPlane)) * StoneHenge_numlevels;
	if (mip >= StoneHenge_numlevels) {
		mip = StoneHenge_numlevels - 1;
	}

	int width = (StoneHenge_width >> mip);
	int hight = (StoneHenge_height >> mip);


	float x = SV_UV.UV[0] * width;
	float y = SV_UV.UV[1] * hight;
	float Rx = x - floorf(x);
	float Ry = y - floorf(y);


	int pos = (static_cast<int>(y) * width) + static_cast<int>(x) + StoneHenge_leveloffsets[mip];
	unsigned TL = StoneHenge_pixels[pos];
	unsigned TR = StoneHenge_pixels[pos+1];
	unsigned BL = StoneHenge_pixels[pos+width];
	unsigned BR = StoneHenge_pixels[pos+width+1];

	unsigned T = Blend(TL, TR, Rx);
	unsigned B = Blend(BL, BR, Rx);
	unsigned COLOR = C2C(Blend(T,B,Ry));

	Color = ColorModulate(COLOR, Light );
}